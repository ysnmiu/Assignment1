module.exports = {
    sessionSecret: 'developmentSessionSecret'
}