function submitForm(){
    window.location.href = "/";
  }